<?php

echo "<script>window.location.href = 's/';</script>";
?>